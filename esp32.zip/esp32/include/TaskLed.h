#ifndef INC_TASKLED_H_
#define INC_TASKLED_H_

#include "globals.h"

#ifdef __cplusplus
extern "C"
{
#endif

    void TaskLed(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* INC_TASKLED_H_ */
