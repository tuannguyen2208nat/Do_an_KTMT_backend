#ifndef INC_TASKTEMPERATUREHUMIDITY_H_
#define INC_TASKTEMPERATUREHUMIDITY_H_

#include "globals.h"

#ifdef __cplusplus
extern "C"
{
#endif

    void TaskTemperatureHumidity(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* INC_TASKTEMPERATUREHUMIDITY_H_ */
