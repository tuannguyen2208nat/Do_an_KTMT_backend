#ifndef INC_TASKSCHEDULE_H_
#define INC_TASKSCHEDULE_H_

#include "globals.h"

#ifdef __cplusplus
extern "C"
{
#endif

    void TaskSchedule(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* INC_TASKSCHEDULE_H_ */
