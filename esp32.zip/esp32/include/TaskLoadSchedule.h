#ifndef INC_TASKLOADSCHEDULE_H_
#define INC_TASKLOADSCHEDULE_H_

#include "globals.h"

#ifdef __cplusplus
extern "C"
{
#endif

    void TaskLoadSchedule(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* INC_TASKLOADSCHEDULE_H_ */
